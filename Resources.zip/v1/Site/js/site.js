var ChatApp = window.ChatApp || {};

(function scopeWrapper($) {

}(jQuery));